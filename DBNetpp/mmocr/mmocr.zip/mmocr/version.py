# Copyright (c) Open-MMLab. All rights reserved.

__version__ = '0.6.3'
short_version = __version__
