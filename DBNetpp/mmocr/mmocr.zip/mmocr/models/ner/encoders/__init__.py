# Copyright (c) OpenMMLab. All rights reserved.
from .bert_encoder import BertEncoder

__all__ = ['BertEncoder']
