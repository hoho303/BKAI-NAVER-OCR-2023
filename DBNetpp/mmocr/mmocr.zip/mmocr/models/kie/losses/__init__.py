# Copyright (c) OpenMMLab. All rights reserved.
from .sdmgr_loss import SDMGRLoss

__all__ = ['SDMGRLoss']
