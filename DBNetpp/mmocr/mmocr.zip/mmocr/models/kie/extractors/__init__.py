# Copyright (c) OpenMMLab. All rights reserved.
from .sdmgr import SDMGR

__all__ = ['SDMGR']
