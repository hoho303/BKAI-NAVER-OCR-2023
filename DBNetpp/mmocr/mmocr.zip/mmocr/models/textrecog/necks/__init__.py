# Copyright (c) OpenMMLab. All rights reserved.
from .fpn_ocr import FPNOCR

__all__ = ['FPNOCR']
